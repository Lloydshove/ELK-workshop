# encoding: utf-8
require "logstash/agent"
require "logstash/event"
require "logstash/namespace"
