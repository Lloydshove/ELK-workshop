require "logstash/inputs/rabbitmq/march_hare"
